package com;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class updemail extends EmpFrame {
	
	int variable3=45;
	void getEId (int value)
	{
		variable3=value;
	}
	updemail()
	{
	f1=new JFrame("Update Email");
	
	lbl1=new JLabel("Enter Employee ID");
	tfd1=new JTextField(10);
	lbl2=new JLabel("Enter New Email Address");
	tfd2=new JTextField(10);
	UpdEmail=new JButton("Update");
	Cancel=new JButton("Cancel");
	f1.add(lbl1);
	f1.add(tfd1);
	f1.add(lbl2);
	f1.add(tfd2);
	f1.add(UpdEmail);
	f1.add(Cancel);
	f1.setLayout(new GridLayout(3, 2, 5, 5));
	f1.setDefaultCloseOperation(HIDE_ON_CLOSE);
	f1.setSize(300, 200);
	f1.setVisible(false);
	f1.setLocationRelativeTo(null);
	
	UpdEmail.addActionListener(this);
	Cancel.addActionListener(this);
	}
		
	public void actionPerformed(ActionEvent e)
	{
	if(e.getSource()==UpdEmail)
		{
		int flag=0;
		try{
			Connection con2=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
			Statement stat=con2.createStatement();
		ResultSet r=stat.executeQuery("SELECT * FROM empdetails");
		while (r.next())
		{
			String EIdstring=tfd1.getText();
			int EIdEmail=Integer.parseInt(EIdstring);
			int temp=r.getInt(1);
			if(temp==EIdEmail && EIdEmail==variable3)
			{
				flag=1;
			}
		}
		if(flag==1)
		{
			String EIdstring=tfd1.getText();
			String NewEmail=tfd2.getText();
			int EIdEmail=Integer.parseInt(EIdstring);
				String updateString1 =
						"update empDetails set EmailId =? where EId = ?";	
				PreparedStatement updateEmail = con2.prepareStatement(updateString1);
				updateEmail.setString(1,NewEmail);
				updateEmail.setInt(2,EIdEmail);
				updateEmail.executeUpdate();
				f1.setVisible(false);
				JOptionPane.showMessageDialog(this,"Email Reset Successful");
			}	
		if(flag==0)
		{
			JOptionPane.showMessageDialog(this,"Wrong EId Entered !");
		}
		}
			catch(SQLException e4)
			{
				e4.printStackTrace();
			}
	}
	if(e.getSource()==Cancel)
		{
			f1.setVisible(false);
			f.setVisible(true);
		}	
	}

public static  void main(String[] args) {	
	updemail updp=new updemail();
	}
}		
