package com;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

import javax.swing.*;

public class LoginFrame extends JFrame implements ActionListener {
	JFrame fl;
	JLabel l1, l2;
	JTextField username;
	JTextField password;
	JButton submit;
	ButtonGroup bg;
	JRadioButton r1, r2;  
	JPanel p1;
	int var;

	LoginFrame() {
		fl = new JFrame();
		p1 = new JPanel();
		l1 = new JLabel("Username");
		l2 = new JLabel("Password");
		username = new JTextField(10);
		password = new JTextField(20);
		bg = new ButtonGroup();
		submit = new JButton("Submit");
		submit.addActionListener(this);
		p1.add(l1);
		p1.add(username);
		p1.add(l2);
		p1.add(password);
		p1.add(submit);
		p1.setBackground(Color.green);
		p1.setSize(20, 20);
		p1.setLayout(new GridLayout(6, 1));
		fl.add(p1);
		fl.setTitle("Login Form");
		fl.setDefaultCloseOperation(HIDE_ON_CLOSE);
		fl.setSize(400, 400);
		fl.setVisible(true);
		fl.setLocationRelativeTo(null);
	}

	int flag = 0;

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == submit) {

			String u1 = username.getText();
			String p1 = password.getText();

			try {
				Connection con2 = DriverManager.getConnection(
						"jdbc:mysql://localhost:3306/test", "root", "root");
				Statement stat = con2.createStatement();
				ResultSet rset = stat.executeQuery("SELECT * FROM empdetails");

				while (rset.next()) {
					String u2 = rset.getString(2);
					String p2 = rset.getString(9);
					if (u1.compareTo(u2) == 0 && p1.compareTo(p2) == 0) {
						if (p1.compareTo(p2) == 0) {
							flag = 1;
							var = rset.getInt(1);
						}

					}

				}

				if (flag == 1) {
					Object[] options = { "Employee", "Admin" };
					int n = JOptionPane.showOptionDialog(fl,
							"Would you like to continue",
							"Authentication Message",
							JOptionPane.YES_NO_OPTION,
							JOptionPane.QUESTION_MESSAGE, null, // do not use a custom Icon
							options, // the titles of buttons
							options[0]); // default button title
					if (n == JOptionPane.YES_OPTION) {
						EmpFrame em = new EmpFrame();
						em.getEId(var);
						em.f.setVisible(true);

					} else if (n == JOptionPane.NO_OPTION) {
						ResultSet rset2 = stat
								.executeQuery("SELECT * FROM empdetails");

						while (rset2.next()) {
							String u2 = rset2.getString(2);
							String p2 = rset2.getString(9);
							if (u1.compareTo(u2) == 0 && p1.compareTo(p2) == 0) {

								if (rset2.getInt(16) == 1) {
									AdminFrame adm = new AdminFrame();
									adm.f.setVisible(true);

								} else {
									JOptionPane.showMessageDialog(this,
											"Authentication Failed !");
								}

							}

						}

					}
				}
				if (flag == 0) {
					JOptionPane.showMessageDialog(this,
							"Authentication Failed !");
				}

			}

			catch (SQLException g) {
				g.printStackTrace();
			}
		}

	}

	public static void main(String args[]) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException c) {
			c.printStackTrace();
		}

		LoginFrame login = new LoginFrame();
	}
}
