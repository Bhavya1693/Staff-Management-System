package com;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class updPass extends EmpFrame {

	int variable2 = 45;

	void getEId(int value) {
		variable2 = value;
	}

	updPass() {
		f2 = new JFrame("Update Password");
		pl1 = new JLabel("Enter Employee ID");
		ps1 = new JTextField(10);
		pl2 = new JLabel("Enter New Password");
		ps2 = new JTextField(10);
		UpdPassword = new JButton("Update");
		Cancel1 = new JButton("Cancel");
		f2.add(pl1);
		f2.add(ps1);
		f2.add(pl2);
		f2.add(ps2);
		f2.add(UpdPassword);
		f2.add(Cancel1);
		f2.setLayout(new GridLayout(3, 2, 5, 5));
		f2.setDefaultCloseOperation(HIDE_ON_CLOSE);
		f2.setSize(300, 200);
		f2.setVisible(false);
		f2.setLocationRelativeTo(null);

		UpdPassword.addActionListener(this);
		Cancel1.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == UpdPassword) {
			int flag = 0;
			try {
				Connection con2 = DriverManager.getConnection(
						"jdbc:mysql://localhost:3306/test", "root", "root");
				Statement stat = con2.createStatement();
				ResultSet r = stat.executeQuery("SELECT * FROM empdetails");
				while (r.next()) {
					String EIdstring = ps1.getText();
					int EIdPass = Integer.parseInt(EIdstring);
					int temp = r.getInt(1);
					if (temp == EIdPass && EIdPass == variable2) {
						flag = 1;
					}
				}
				if (flag == 1) {
					String NewPass = ps2.getText();
					String EIdstring = ps1.getText();
					int EIdPass = Integer.parseInt(EIdstring);
					String updateString1 = "update empDetails set Password =? where EId = ?";
					PreparedStatement updatePassword = con2
							.prepareStatement(updateString1);
					updatePassword.setString(1, NewPass);
					updatePassword.setInt(2, EIdPass);
					updatePassword.executeUpdate();
					f2.setVisible(false);
					JOptionPane.showMessageDialog(this,
							"Password Reset Successful");
				}
				if (flag == 0) {
					JOptionPane.showMessageDialog(this, "Wrong EId Entered !");
				}
			} catch (SQLException g) {
				g.printStackTrace();
			}
		}
		if (e.getSource() == Cancel1) {
			f2.setVisible(false);
			f.setVisible(true);
		}
	}

	public static void main(String[] args) {
		updPass updp = new updPass();
	}
}
