package com;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.sql.Date;

import javax.swing.*;

import com.mysql.jdbc.PreparedStatement;

import java.util.*;
import java.text.*;

public class EmpFrame extends JFrame implements ActionListener {

	// Frames
	JFrame f, f1, f2, f3;
	// Employee ID
	JLabel lbl;
	JTextField txt;
	JButton OK;
	// Employee form panels
	JPanel p1, p2;
	// Employee Details Swings
	JTextField t1, t2, t3, t4, t5, t6, t7, t8;
	JLabel l1, l2, l3, l4, l5, l6, l7, l8;
	// Salary Details Swings
	JTextField tf1, tf2, tf3, tf4, tf5, tf6;
	JLabel lb1, lb2, lb3, lb4, lb5, lb6;
	// menu
	JMenu View, Update;
	JMenuItem Profile, Salary_Details, Attendance, Password, Email;
	JMenuBar mb;
	// Logout Button
	JButton b1;
	// Password frame Swings
	JTextField ps1, ps2;
	JLabel pl1, pl2;
	JButton UpdPassword, Cancel1;
	// Email Form Swings
	JTextField tfd1, tfd2;
	JLabel lbl1, lbl2;
	JButton UpdEmail, Cancel;

	EmpFrame() {
		f = new JFrame("Employee");
		// Employee and Salary Details Form
		mb = new JMenuBar();
		p1 = new JPanel(new GridLayout(1, 2));
		p1.setSize(10, 500);
		p2 = new JPanel(new FlowLayout());

		View = new JMenu("View");
		Update = new JMenu("Update");

		Profile = new JMenuItem("Profile");
		Salary_Details = new JMenuItem("Salary Details");

		// Attendance=new JMenuItem("Attendance");
		Password = new JMenuItem("Password");
		Email = new JMenuItem("Email");
		View.add(Profile);
		View.addSeparator();
		View.add(Salary_Details);
		View.addSeparator();

		// View.add(Attendance);
		Update.add(Password);
		Update.addSeparator();
		Update.add(Email);

		mb.add(View);
		mb.add(Update);

		l1 = new JLabel("Employee ID");
		t1 = new JTextField(5);
		l2 = new JLabel("Name");
		t2 = new JTextField(10);
		l3 = new JLabel("D.O.B");
		t3 = new JTextField(10);
		l4 = new JLabel("Age");
		t4 = new JTextField(5);
		l5 = new JLabel("Sex");
		t5 = new JTextField(5);
		l6 = new JLabel("Date Of Join");
		t6 = new JTextField(10);
		l7 = new JLabel("Email");
		t7 = new JTextField(10);
		l8 = new JLabel("Attendence");
		t8 = new JTextField(10);

		b1 = new JButton("Log Out");
		b1.setSize(10, 10);

		p1.add(l1);
		p1.add(t1);
		p1.add(l2);
		p1.add(t2);
		p1.add(l3);
		p1.add(t3);
		p1.add(l4);
		p1.add(t4);
		p1.add(l5);
		p1.add(t5);
		p1.add(l6);
		p1.add(t6);
		p1.add(l7);
		p1.add(t7);
		p1.add(l8);
		p1.add(t8);

		p1.setBackground(Color.orange);
		p1.setSize(20, 20);
		p1.setLayout(new GridLayout(3, 3));

		lb1 = new JLabel("Gross");
		tf1 = new JTextField(5);
		lb2 = new JLabel("DA");
		tf2 = new JTextField(10);
		lb3 = new JLabel("TA");
		tf3 = new JTextField(10);
		lb4 = new JLabel("HRA");
		tf4 = new JTextField(5);
		lb5 = new JLabel("Special");
		tf5 = new JTextField(5);
		lb6 = new JLabel("Total");
		tf6 = new JTextField(10);

		p2.add(lb1);
		p2.add(tf1);
		p2.add(lb2);
		p2.add(tf2);
		p2.add(lb3);
		p2.add(tf3);
		p2.add(lb4);
		p2.add(tf4);
		p2.add(lb5);
		p2.add(tf5);
		p2.add(lb6);
		p2.add(tf6);

		p2.setBackground(Color.LIGHT_GRAY);
		p2.setSize(20, 20);
		p2.setLayout(new GridLayout(3, 2));

		f.add(mb);
		f.add(p1);
		f.add(p2);
		f.add(b1);
		f.setLayout(new GridLayout(4, 1));

		Profile.addActionListener(this);
		Salary_Details.addActionListener(this);

		// Attendance.addActionListener(this);
		Password.addActionListener(this);
		Email.addActionListener(this);
		b1.addActionListener(this);

		f.setDefaultCloseOperation(HIDE_ON_CLOSE);
		f.setSize(1000, 500);
		f.setLocationRelativeTo(null);

	}

	int variable = 45;

	void getEId(int value) {
		variable = value;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// Functionality of view Menu
		if (e.getSource() == Profile) {
			f.setVisible(true);

			try {
				Connection con2 = DriverManager.getConnection(
						"jdbc:mysql://localhost:3306/test", "root", "root");
				Statement stat = con2.createStatement();
				ResultSet r = stat.executeQuery("SELECT * FROM empdetails");
				while (r.next()) {
					int temp = r.getInt(1);
					if (temp == variable) {
						Integer EId = r.getInt(1);
						String EmpName = r.getString(2);

						DateFormat dateFormat = new SimpleDateFormat();
						Date DOb = r.getDate(3);

						Integer Age = r.getInt(4);
						String sex = r.getString(5);

						DateFormat dateFormat1 = new SimpleDateFormat();
						Date DOJ = r.getDate(6);

						String EmailId = r.getString(7);
						Integer Attendance = r.getInt(8);

						String EId1 = String.valueOf(EId);
						String Age1 = String.valueOf(Age);
						String DObString = dateFormat.format(DOb);
						String DOJString = dateFormat1.format(DOJ);
						String Attendance1 = String.valueOf(Attendance);

						t1.setText(EId1);
						t2.setText(EmpName);
						t3.setText(DObString);
						t4.setText(Age1);
						t5.setText(sex);
						t6.setText(DOJString);
						t7.setText(EmailId);
						t8.setText(Attendance1);
					}

				}

			}

			catch (SQLException g) {
				g.printStackTrace();
			}
		}

		if (e.getSource() == Salary_Details) {
			try {
				Connection con2 = DriverManager.getConnection(
						"jdbc:mysql://localhost:3306/test", "root", "root");
				Statement stat = con2.createStatement();
				ResultSet r1 = stat.executeQuery("SELECT * FROM empdetails");
				while (r1.next()) {
					int temp = r1.getInt(1);
					if (temp == variable) {
						Integer Gross = r1.getInt(10);
						Integer DA = r1.getInt(11);
						Integer TA = r1.getInt(12);
						Integer HRA = r1.getInt(13);
						Integer Special = r1.getInt(14);
						Integer Total = r1.getInt(15);

						String Gross1 = String.valueOf(Gross);
						String DA1 = String.valueOf(DA);
						String TA1 = String.valueOf(TA);
						String HRA1 = String.valueOf(HRA);
						String Special1 = String.valueOf(Special);
						String Total1 = String.valueOf(Total);

						tf1.setText(Gross1);
						tf2.setText(DA1);
						tf3.setText(TA1);
						tf4.setText(HRA1);
						tf5.setText(Special1);
						tf6.setText(Total1);
					}
				}
			} catch (SQLException g) {
				g.printStackTrace();
			}
		}

		// Functionality of LogOut button
		if (e.getSource() == b1) {
			System.exit(0);

		}
		// Functionality of Update menu
		// Password
		if (e.getSource() == Password) {
			updPass up1 = new updPass();

			up1.f2.setVisible(true);
			up1.getEId(variable);
			f.setVisible(false);
		}

		// E-mail
		if (e.getSource() == Email) {
			updemail up2 = new updemail();
			up2.f1.setVisible(true);
			up2.getEId(variable);
			f.setVisible(false);
		}
	}

	public static void main(String[] args) {
		EmpFrame emp = new EmpFrame();
	}
}
