package com;

import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;
import javax.swing.*;

public class AdminFrame extends JFrame implements ActionListener {

	ImageIcon img;
	JLabel limg;
	// Frames
	JFrame f, f1, f2;
	// Main Admin Form
	JPanel p1, p2, p3;
	// New Employee Details Swings
	JTextField t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13, t14,
			t15;
	JLabel l1, l2, l3, l4, l5, l6, l7, l8, l9, l10, l11, l12, l13, l14, l15;
	JTextField tf1, tf2, tf3, tf4, tf5, tf6;
	JLabel lb1, lb2, lb3, lb4, lb5, lb6;
	JButton b1, b2;

	// menu
	JButton Add_NewEmployee, Delete_Employee;

	// Delete Employee
	JLabel lb;
	JTextField tf;
	JButton Delete, Cancel;

	AdminFrame() {
		f = new JFrame("Admin");
		f1 = new JFrame("Enter Details");
		f2 = new JFrame("Delete Employee");
		// Admin Form
		img = new ImageIcon(getClass().getResource("w.jpg"));
		limg = new JLabel(img);
		limg.setSize(400, 1000);
		f.add(limg);
		f.pack();

		p1 = new JPanel(new FlowLayout());
		p2 = new JPanel(new FlowLayout());
		p3 = new JPanel(new FlowLayout());

		Add_NewEmployee = new JButton("Add Employee");
		Delete_Employee = new JButton("Delete Employee");

		p3.setSize(500, 500);
		p3.setLayout(new GridLayout(3, 2));
		p3.setVisible(true);

		// Employee Details Form
		l1 = new JLabel("Employee ID");
		t1 = new JTextField(5);
		l2 = new JLabel("Name");
		t2 = new JTextField(10);
		l3 = new JLabel("D.O.B");
		t3 = new JTextField(10);
		l4 = new JLabel("Age");
		t4 = new JTextField(5);
		l5 = new JLabel("Sex");
		t5 = new JTextField(5);
		l6 = new JLabel("Date Of Join");
		t6 = new JTextField(10);
		l7 = new JLabel("Email");
		t7 = new JTextField(10);
		l8 = new JLabel("Attendence");
		t8 = new JTextField(10);
		l9 = new JLabel("Password");
		t9 = new JTextField(10);
		l10 = new JLabel("Gross");
		t10 = new JTextField(10);
		l11 = new JLabel("TA");
		t11 = new JTextField(10);
		l12 = new JLabel("DA");
		t12 = new JTextField(10);
		l13 = new JLabel("HRA");
		t13 = new JTextField(10);
		l14 = new JLabel("Special");
		t14 = new JTextField(10);
		l15 = new JLabel("Total");
		t15 = new JTextField(10);

		b1 = new JButton("OK");
		b1.setSize(20, 20);
		b2 = new JButton("cancel");
		b2.setSize(20, 20);

		f.add(Add_NewEmployee);
		f.add(Delete_Employee);
		f.add(p3);
		f.setLayout(new FlowLayout(3, 3, 5));
		f.setDefaultCloseOperation(HIDE_ON_CLOSE);
		f.setSize(300, 200);
		f.setVisible(true);
		f.setLocationRelativeTo(null);

		p1.add(l1);
		p1.add(t1);
		p1.add(l2);
		p1.add(t2);
		p1.add(l3);
		p1.add(t3);
		p1.add(l4);
		p1.add(t4);
		p1.add(l5);
		p1.add(t5);
		p1.add(l6);
		p1.add(t6);
		p1.add(l7);
		p1.add(t7);
		p1.add(l8);
		p1.add(t8);

		p1.add(l9);
		p1.add(t9);
		p1.add(l10);
		p1.add(t10);
		p1.add(l11);
		p1.add(t11);
		p1.add(l12);
		p1.add(t12);
		p1.add(l13);
		p1.add(t13);
		p1.add(l14);
		p1.add(t14);
		p1.add(l15);
		p1.add(t15);
		p1.add(b1);
		p1.add(b2);

		p1.setBackground(Color.cyan);
		p1.setSize(300, 300);
		p1.setLayout(new GridLayout(6, 5, 6, 5));

		lb1 = new JLabel("Gross");
		tf1 = new JTextField(5);
		lb2 = new JLabel("DA");
		tf2 = new JTextField(10);
		lb3 = new JLabel("TA");
		tf3 = new JTextField(10);
		lb4 = new JLabel("HRA");
		tf4 = new JTextField(5);
		lb5 = new JLabel("Special");
		tf5 = new JTextField(5);
		lb6 = new JLabel("Total");
		tf6 = new JTextField(10);

		p2.add(lb1);
		p2.add(tf1);
		p2.add(lb2);
		p2.add(tf2);
		p2.add(lb3);
		p2.add(tf3);
		p2.add(lb4);
		p2.add(tf4);
		p2.add(lb5);
		p2.add(tf5);
		p2.add(lb6);
		p2.add(tf6);

		p2.setBackground(Color.green);
		p2.setSize(100, 100);
		p2.setLayout(new GridLayout(3, 2));

		// Delete Employee Form
		lb = new JLabel("Enter Employee ID");
		tf = new JTextField(10);
		Delete = new JButton("Delete Entry");
		Cancel = new JButton("Cancel");
		Delete.addActionListener(this);
		Cancel.addActionListener(this);

		f.add(p3);
		f.setLayout(new FlowLayout());
		f.setDefaultCloseOperation(HIDE_ON_CLOSE);
		f.setSize(500, 500);
		f.setVisible(true);
		f.setLocationRelativeTo(null);

		f1.add(p1);
		f1.setLayout(new GridLayout(1, 1));
		f1.setDefaultCloseOperation(HIDE_ON_CLOSE);
		f1.setSize(1000, 400);
		f1.setVisible(false);
		f1.setLocationRelativeTo(null);

		f2.add(lb);
		f2.add(tf);
		f2.add(Delete);
		f2.add(Cancel);
		f2.setLayout(new GridLayout(4, 4, 5, 5));
		f2.setDefaultCloseOperation(HIDE_ON_CLOSE);
		f2.setSize(300, 300);
		f2.setVisible(false);
		f2.setLocationRelativeTo(null);

		b1.addActionListener(this);
		b2.addActionListener(this);
		Add_NewEmployee.addActionListener(this);
		Delete_Employee.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent ae) {

		if (ae.getSource() == Add_NewEmployee) {
			f.setVisible(false);
			f1.setVisible(true);
		}
		if (ae.getSource() == b1) {
			String NewEmp = "insert into empDetails values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			try {
				Connection con2 = DriverManager.getConnection(
						"jdbc:mysql://localhost:3306/test", "root", "root");
				con2.setAutoCommit(true);
				PreparedStatement statement = con2.prepareStatement(NewEmp);
				statement.setInt(1, Integer.parseInt(t1.getText()));
				statement.setString(2, t2.getText());
				statement.setString(3, null);
				statement.setInt(4, Integer.parseInt(t4.getText()));
				statement.setString(5, t5.getText());
				statement.setString(6, null);
				statement.setString(7, t7.getText());
				statement.setInt(8, Integer.parseInt(t8.getText()));
				statement.setString(9, t9.getText());
				statement.setInt(10, Integer.parseInt(t10.getText()));
				statement.setInt(11, Integer.parseInt(t10.getText()));
				statement.setInt(12, Integer.parseInt(t11.getText()));
				statement.setInt(13, Integer.parseInt(t12.getText()));
				statement.setInt(14, Integer.parseInt(t13.getText()));
				statement.setInt(15, Integer.parseInt(t14.getText()));
				statement.setInt(16, 0);

				statement.executeUpdate();
			} catch (SQLException e4) {
				e4.printStackTrace();
			}

			JOptionPane.showMessageDialog(this,
					"Employee has been added ! \nLogin password is 'welcome'");
		}

		if (ae.getSource() == b2) {
			f.setVisible(true);
			f1.setVisible(false);
		}

		if (ae.getSource() == Delete_Employee) {
			f.setVisible(false);
			f2.setVisible(true);
		}

		if (ae.getSource() == Delete) {
			int flag = 0;
			try {
				Connection con2 = DriverManager.getConnection(
						"jdbc:mysql://localhost:3306/test", "root", "root");
				con2.setAutoCommit(true);
				Statement stat = con2.createStatement();
				ResultSet r = stat.executeQuery("SELECT * FROM empdetails");
				while (r.next()) {
					String EIdstring = tf.getText();
					int EIdPass = Integer.parseInt(EIdstring);
					int temp = r.getInt(1);
					if (temp == EIdPass) {
						flag = 1;
					}
				}
				if (flag == 1) {

					String NewEmp = "Delete From empdetails Where EId=?";
					PreparedStatement statement = con2.prepareStatement(NewEmp);
					statement.setInt(1, Integer.parseInt(tf.getText()));
					statement.executeUpdate();
				}
			} catch (SQLException e4) {
				e4.printStackTrace();
			}
			JOptionPane.showMessageDialog(this, "Employee has been Deleted");

			if (flag == 0) {
				JOptionPane.showMessageDialog(this, "Wrong EId Entered !");
			}
		}

		if (ae.getSource() == Cancel) {
			f.setVisible(true);
			f2.setVisible(false);
		}

	}

	public static void main(String[] args) {
		AdminFrame emp1 = new AdminFrame();
	}
}
